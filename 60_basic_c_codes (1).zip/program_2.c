#include <stdio.h>

int main() {
    printf("This is sample C program #2\n");
    return 0;
}
