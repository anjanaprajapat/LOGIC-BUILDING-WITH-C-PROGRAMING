#include <stdio.h>

int main() {
    printf("This is sample C program #11\n");
    return 0;
}
