#include <stdio.h>

int main() {
    printf("This is sample C program #3\n");
    return 0;
}
