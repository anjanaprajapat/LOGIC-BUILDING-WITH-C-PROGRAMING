#include <stdio.h>

int main() {
    printf("This is sample C program #36\n");
    return 0;
}
