#include <stdio.h>

int main() {
    printf("This is sample C program #46\n");
    return 0;
}
