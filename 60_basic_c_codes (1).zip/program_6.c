#include <stdio.h>

int main() {
    printf("This is sample C program #6\n");
    return 0;
}
