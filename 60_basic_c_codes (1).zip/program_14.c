#include <stdio.h>

int main() {
    printf("This is sample C program #14\n");
    return 0;
}
