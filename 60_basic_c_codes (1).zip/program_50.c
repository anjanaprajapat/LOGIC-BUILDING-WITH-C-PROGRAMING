#include <stdio.h>

int main() {
    printf("This is sample C program #50\n");
    return 0;
}
