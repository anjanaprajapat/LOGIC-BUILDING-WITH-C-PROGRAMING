#include <stdio.h>

int main() {
    printf("This is sample C program #8\n");
    return 0;
}
