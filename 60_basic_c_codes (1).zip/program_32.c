#include <stdio.h>

int main() {
    printf("This is sample C program #32\n");
    return 0;
}
