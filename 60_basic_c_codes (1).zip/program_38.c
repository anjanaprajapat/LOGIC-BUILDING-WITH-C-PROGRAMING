#include <stdio.h>

int main() {
    printf("This is sample C program #38\n");
    return 0;
}
