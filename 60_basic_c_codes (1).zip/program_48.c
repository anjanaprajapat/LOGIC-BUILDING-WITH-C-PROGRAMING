#include <stdio.h>

int main() {
    printf("This is sample C program #48\n");
    return 0;
}
