#include <stdio.h>

int main() {
    printf("This is sample C program #44\n");
    return 0;
}
