#include <stdio.h>

int main() {
    printf("This is sample C program #25\n");
    return 0;
}
