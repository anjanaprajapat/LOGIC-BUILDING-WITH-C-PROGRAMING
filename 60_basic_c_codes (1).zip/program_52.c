#include <stdio.h>

int main() {
    printf("This is sample C program #52\n");
    return 0;
}
