#include <stdio.h>

int main() {
    printf("This is sample C program #21\n");
    return 0;
}
