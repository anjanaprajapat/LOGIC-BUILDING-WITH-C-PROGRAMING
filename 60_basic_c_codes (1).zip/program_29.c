#include <stdio.h>

int main() {
    printf("This is sample C program #29\n");
    return 0;
}
