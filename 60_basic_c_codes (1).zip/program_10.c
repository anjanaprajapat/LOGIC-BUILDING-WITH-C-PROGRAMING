#include <stdio.h>

int main() {
    printf("This is sample C program #10\n");
    return 0;
}
