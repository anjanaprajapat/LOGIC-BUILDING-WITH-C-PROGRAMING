#include <stdio.h>

int main() {
    printf("This is sample C program #1\n");
    return 0;
}
